 --- 
author: "Ambrosia Law" 
date: 2019-02-11 
title: Is CBD Legal in Louisiana? 
best: false 
tags: ["CBD","Cannabidiol","hemp","marijuana","cannabis","attorney","lawyer","new orleans"] 
--- 
<!-- Global site tag (gtag.js) - Google Analytics --> 

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script> 

<script> 

  window.dataLayer = window.dataLayer || []; 

  function gtag(){dataLayer.push(arguments);} 

  gtag('js', new Date()); 

  

  gtag('config', 'UA-100888059-7'); 
</script> 


# IS CBD Legal In Louisiana? 

![Louisiana CBD Law](/img/louisiana-cannabis-marijuana-cbd-law.jpg "Louisiana CBD Law")

## Analyzing the Legal status of CBD (Cannabidiol) in New Orleans, Louisiana 

This article analyzes whether Cannabidiol (“CBD”) is legal under Louisiana law. ⚖️ Generally, the following research focuses on Louisiana cannabis laws.  🌱 This article also focuses on Louisiana cannabidiol law in particular.  

This article is an informal analysis drafted by a lisenced attorney.  Nonethless, this article does not reflect the opinions of Ambrosia Law Corporation or its affiliates and is not legal advice for you.    

_Note: This Content is NOT legal advice and should NOT be taken as such._  - _If you have a legal question, please consult with an attorney._  

## CBD Background 

CBD is hot right now. 🔥 CBD is popping up everywhere.  These days, CBD is being infused into:  bath bombs, gummy candies, oils, tinctures, vape cartridges, dog treats, lotions, salves, and a variety of other consumables.   

Despite its recent rise in popularity, CBD remains a mystery to many people.  For the uninitiated, CBD is an acronym for Cannabidiol, a naturally occurring cannabinoid and a component part of cannabis plant (known colloquially as “marijuana”).  🌿 

Two primary compounds within cannabis plant matter, Δ9-tetrahydrocannabinol (THC) and cannabidiol (CBD), are both psychoactive, but only THC is considered intoxicating.  Solowij, N., Broyd, S., Greenwood, L. et al. Eur Arch Psychiatry Clin Neurosci (2019). https://doi.org/10.1007/s00406-019-00978-2. 

 CBD has become a major area of research in recent years.  In particular, its biological actions are a topic of many interesting reports that suggest possible therapeutic applications. Burstein, S., Cannabidiol (CBD) and its analogs: a review of their effects on inflammation. Bioorganic & Medicinal Chemistry (2015). https://doi.org/10.1016/j.bmc.2015.01.059  Popular CBD research includes its anti-inflammatory actions in a variety of preclinical models. Some examples are experimental colitis, collagen-induced arthritis, b-amyloid-induced neuroinflammation, neutrophil chemotaxis, hepatic ischemiareperfusion (I/R) injury, autoimmune encephalomyelitis, acute lung injury (ALI), etc.  _Id_.  These and others need to be pursued in human trials with a view toward clinical applications where CBD’s absence of psychotropic effects and other adverse events offers a major advantage over other cannabinoids. _Id_.   

Ultimately, the recent nationwide movement towards cannabis legalization at the state level resulted in CBD’s rise in popularity as an alternative way to treat pain, anxiety, insomnia, and a variety of other conditions.   

## What are Louisiana CBD Laws?  What are Louisiana State Cannabis Laws? 

Recently, New Orleans retailers began selling CBD in a variety of popular forms.  Throughout Louisiana, CBD is popping up for sale in gas stations, vape shops, tobacco (“head”) shops, spas, CBD specialty shops, and a variety of other types of retail locations. 

Some retailers maintain the position that is legal to buy and sell CBD by citing the USC Agricultural Act and other similar authorities. This position is flawed for it does not consider issues arising from the conflicts of law.  

[This Article](https://www.wwltv.com/article/news/local/atc-cracking-down-on-select-cbd-sales/289-524638645) explains how the Louisiana ATC recently cracked down on local CBD sales.  

## What are Louisiana Controlled Dangerous Substances Laws? 

Now that we know what Cannabidiol is, let’s begin our analysis of whether is Cannabidiol legal in Louisiana.  Louisiana Revised Statutes Title 40 governs “Public Health and Safety.”   [Section 963 of  Title 40 of the Louisiana Revised Statutes (LA RS 40:963)](https://www.legis.la.gov/legis/Law.aspx?d=98876) is titled “Schedules of controlled dangerous substances.”   This section establishes Louisiana’s five schedules of controlled substances and lists the basis for classifying substances into their respective schedules.   

Additionally, this section, LA R.S. 40:963, states “such schedules shall initially consist of the substances listed in R.S. 40:964.”  This is important because LA R.S. 40:963 directs us towards the appropriate list of schedules.  Naturally, it follows that we should refer to [LA R.S. 40:964](https://www.legis.la.gov/legis/Law.aspx?p=y&d=98877) to determine what substances are listed in each schedule.  

Nevertheless, before we make a determination regarding what schedule Cannabidiol is listed in, let’s look to [LA R.S. 40:961](https://www.legis.la.gov/legis/Law.aspx?d=98873) entitled “Definitions” to gain a better understanding of the meaning of the terms used in these statutes.  This statute, LA R.S. 40:961, commences “PART X”, the “UNIFORM CONTROLLED DANGEROUS SUBSTANCES LAW” of the revised statutes. 

## What are Controlled Dangerous Substances in Louisiana? 

The relevant portions of the statute, LA R.S. 40:961, read as follows: 

“§961. Definitions 

As used in this Part, the following terms shall have the meaning ascribed to them in this Section unless the context clearly indicates otherwise: 

(6) "Cannabis" includes all parts of plants of the genus Cannabis, whether growing or not; the seeds thereof; the resin extracted from any part of such plant, and every compound, manufacture, salt, derivative, mixture, or preparation of such plant, its seeds or resin, but shall not include the mature stalks of such plant, fiber produced from such stalks, oil or cake made from the seeds of such plant, any other compound, manufacture, salt, derivative, mixture, or preparation of such mature stalks (except the resin extracted therefrom), fiber, oil, or cake or the sterilized seed of such plant which is incapable of germination.” 

Wow.  This is some pretty dense language.  Let’s unpack this and try to break things down to layman’s terms.  

## Cannabis Defined Under Louisiana Law 

Basically, section (6) of LA R.S. 40:961 “defines” what the term “cannabis” actually means in Louisiana.  Section (6) begins by stating that "cannabis" includes all parts of plants of the genus cannabis, whether growing or not; the seeds thereof; the resin extracted from any part of such plant, and every compound, manufacture, salt, derivative, mixture, or preparation of such plant, its seeds or resin.  This language is incredibly broad and encompasses *all* living and dead parts of the cannabis plant.  LA R.S. 40:961(6) applies to all species of cannabis: cannabis sativa, cannabis indica, and cannabis ruderalis.  The legal definition of cannabis includes: roots, stems, seeds, leaves, buds, flowers, pollen sacs, etc.  Moreover, the language is broad enough to encompass compounds derived from all parts of the cannabis plant, including things like cannabis wax, cannabis oils, cannabis tinctures, cannabis edibles, etc.   

As we continue parsing the language of LA R.S. 40:961(6), we arrive at an interesting “safe harbor” indicator.  In particular, LA R.S. 40:961(6) reads: “*but shall not* include the mature stalks of such plant, fiber produced from such stalks, oil or cake made from the seeds of such plant, any other compound, manufacture, salt, derivative, mixture, or preparation of such mature stalks (except the resin extracted therefrom), fiber, oil, or cake or the sterilized seed of such plant which is incapable of germination.”   

Did you catch that?   According to the plain language of this statute, LA R.S. 40:961(6), the term “cannabis” does *not* include the “mature stalks of such plant, its seeds or resin.”   

Ultimately, in Louisiana, the definition of cannabis includes *all* parts of plants of the genus Cannabis, whether growing or not; however, *shall not* include the mature stalks of such plant.   

🤔 O.K.  This seems somewhat contradictory and paradoxical.  Nevertheless, the language of this definition leaves room for attorneys to make creative arguments on both sides of the equation, both for and against Cannabidiol being considered part of the Cannabis plant.    

## What is the Definition of “Manufacture” Under Louisiana Law? 

The statute, [LA RS 40:961(25)](https://www.legis.la.gov/Legis/Law.aspx?d=98873), continues by defining the term manufacture:   

(25) "Manufacture" means the production, preparation, propagation, compounding, or processing of a controlled dangerous substance, either directly or indirectly by extraction from substances of natural origin, or independently by means of chemical synthesis, or by a combination of extraction and chemical synthesis. Manufacturer includes any person who packages, repackages, or labels any container of any controlled dangerous substance, except practitioners who dispense or compound prescription orders for delivery to the ultimate consumer. 

This is self-explanatory.  As we’ve seen before, the language of this statute, LA RS 40:961(25), is very broad.  The language of LA RS 40:961(25) is broad enough to encompass many of the activities that produce derivatives of the cannabis plant, such as the extraction of concentrates.  Moreover, the plaint language of this statute, LA RS 40:961(25), considers chemical synthesis of the chemical constituents of the cannabis plant a “manufacturing” process.  

## What are Louisiana Marijuana Laws? 

Further, LA R.S. 40:961 defines the term “Marijuana” by using the same language that is used to define the term cannabis.  Regarding the definition of “Marijuana,” [LA RS 40:961(26)](https://www.legis.la.gov/Legis/Law.aspx?d=98873) states: 

“(26) "Marijuana" means all parts of plants of the genus Cannabis, whether growing or not; the seeds thereof; the resin extracted from any part of such plant; and every compound, manufacture, salt, derivative, mixture, or preparation of such plant, its seeds or resin, but shall not include the mature stalks of such plant, fiber produced from such stalks, oil or cake made from the seeds of such plant, any other compound, manufacture, salt, derivative, mixture, or preparation of such mature stalks (except the resin extracted therefrom), fiber, oil, or cake, or the sterilized seed of such plant which is incapable of germination, or cannabidiol when contained in a drug product approved by the United States Food and Drug Administration.” 

The language of LA R.S. 40:961(26) that defines “marijuana” is very similar to that of LA R.S. 40:961(6) that defines “cannabis.”  Ultimately, the language of the aforesaid statute, LA R.S. 40:961(26), defines “Marijuana” as a form of “Cannabis.” 

## What are Louisiana’s Controlled Dangerous Substances Schedules? 

Louisiana’s schedules of controlled dangerous substances categorize substances based on a variety of factors including potential for abuse, medical use, and public safety.  [LA RS 40:963](https://www.legis.la.gov/legis/Law.aspx?d=98876) states the criteria for each of the five schedules of controlled substances.  Particularly, LA RS 40:963 reads:  

“In determining that a substance is to be added to these schedules, the secretary shall find the following: 

A. As to Schedule I: 

(1) The drug or other substance has a high potential for abuse. 

(2) The drug or other substance has no currently accepted medical use in treatment in the United States, and 

(3) There is a lack of accepted safety for use of the drug or other substance under medical supervision.” 

Here, based on the language of LA R.S. 40:963, Schedule 1 substances have a high potential for abuse, have no accepted medical use, and are not safe to use.  Armed with this knowledge, let’s figure out what substances fall into which schedule.  

## Louisiana Controlled Subtances Schedule Compositions 

LA RS 40:964 establishes the composition of the schedules of controlled substances in Louisiana.  Particularly relevant is RS 40:964 Composition of schedules, Schedule I, C. Hallucinogenic substances (19) Marihuana. 

“Marihuana” is a schedule I controlled substance.   

But, wait . . . What is “Marihuana”? 

## Marijuana vs. Marihuana  

Our previous analysis of [LA R.S. 40:961](https://www.legis.la.gov/Legis/Law.aspx?d=98873) revealed that LA RS 40:961(26) defines the term “Marijuana.”  Nevertheless, “Marijuana” is NOT “Marihuana.”  LA R.S. 40:961 does not define the term “Marihuana.”   

Ultimately, given that the two words, “Marijuana” and “Marihunana”,  are similar, it is likely that a court would look past the statute’s sloppy drafting and interpret the term “Marihuana” to mean “Marijuana.” 

## Tetrahydrocannabinols, including synthetic equivalents and derivatives. Louisiana THC Laws. 

The next relevant portion of the Schedule Composition statute, [LA R.S. 40:964](https://www.legis.la.gov/legis/Law.aspx?d=98877), regulates Tetrahydrocannabinol (“THC”).  LA R.S. 40:964 is titled: 

“(27) Tetrahydrocannabinols, including synthetic equivalents and derivatives” 

The subheading of this section, LA R.S. 40:964(C), classifies THC as a hallucinogen and states: 

“C. Hallucinogenic substances. Unless specifically excepted or unless listed in another schedule, any material, compound, mixture, or preparation, which contains any quantity of the following hallucinogenic substances, or which contains any of their salts, isomers, or salts of isomers, whenever the existence of such salts, isomers, or salts of isomers is possible within the specific chemical designation, for purposes of this Paragraph only, the term "isomer" includes the optical, position, and geometric isomers:” 

The aforesaid statutory language regarding hallucinogens, in particular, THC, effectively out-laws all forms of THC in the state of Louisiana.  Thus, CBD products that contain small or “trace” amounts of THC are likely considered illegal under Louisiana law.   

## What are Louisiana’s Laws for Synthetic Cannabinoids?  

Section F of [LA R.S. 40:964] (https://www.legis.la.gov/legis/Law.aspx?d=98877) regulates Synthetic Cannabinoids and casts a very broad net regarding what substances constitute synthetic cannabinoids.  Particularly, sections (8) and (9) reference the terms “cannabis” or “cannabinoid” directly.   The relevant language of the statute is reproduced below:  

“F. Synthetic *cannabinoids*. Unless specifically excepted, or contained within a pharmaceutical product approved by the United States Food and Drug Administration, or unless listed in another schedule, any material, compound, mixture, or preparation, which contains any quantity of a synthetic *cannabinoid* found to be in any of the following individual compounds or chemical groups, or any of those individual compounds or groups which contain any synthetic *cannabinoid* salts, isomers, salts of isomers, or nitrogen-heterocyclic analogs, whenever the existence of such salts, isomers, salts of isomers, or  nitrogen-heterocyclic analogs is possible within the specific compounds or chemical groups: 

(8) Tetrahydrodibenzopyrans whether or not substituted in the tricyclic ring system except where contained in *cannabis* or *cannabis* resin. 

(9) Hexahydrodibenzopyrans whether or not substituted in the tricyclic ring system except where contained in *cannabis* or *cannabis* resin.” 

In sum, synthetic cannabinoids are generally illegal under Louisiana law.   

## Cannabidiol as a Schedule V Controlled Substance under Louisiana Law.  

Recall that LA R.S. 40:963 establishes the basis for classifying a substance as a Schedule V controlled substance: 

“E. As to Schedule V: 

(1) The drug or other substance has a low potential for abuse relative to the drugs or other substances listed in Schedule IV. 

(2) The drug or other substance has a currently accepted medical use in treatment in the United States, and 

(3) Abuse of the drug or other substance may lead to limited physical dependence or psychological dependence relative to the drugs or other substances listed in Schedule “ 

Further, the section of [LA R.S. 40:964](https://www.legis.la.gov/legis/Law.aspx?d=98877) that governs Schedule V controlled substances specifically references Cannabidiol (CBD) at sub-section (F).   The text of sub-section (F) states: 

“F. Hallucinogens. 

(1) (2-[3-Methyl-6-(1-methylethenyl)-2-cyclohexen-1-yl]-5-pentyl-1,3-benzenediol) cannabidiol when contained in a drug product approved by the United States Food and Drug Administration.” 

The language of sub section (F) is self-explanatory.  Essentially, in Louisiana, Cannabidiol is considered a Schedule V controlled substance when it is contained in a “drug product” approved by the United States Food and Drug Administration (“FDA”).  Here, based on the language of this section, LA R.S. 40:964(F), it is necessary to consider the definition of the term “drug” to further elucidate the aplicability of this statute.   

## What is the Definition of a “Drug” in Louisiana Law? 

Section (17) of RS 40:961 defines the term “Drug”: 

“(17) "Drug" means: 

(a) Articles recognized in the official United States Pharmacopoeia, official Homeopathic Pharmacopoeia of the United States, or official National Formulary, or any supplement to any of them. 

(b) Articles intended for use in the diagnosis, cure, mitigation, treatment, or prevention of disease in man or other animals. 

( c ) Articles other than food intended to affect the structure of any function of the body of man or other animals. 

(d) Articles intended for use as a component of any article specified in Subparagraph (a), (b), or ( c ) of this Paragraph, but does not include devices or their components, parts, or accessories.” 

Here, the language of LA R.S. 40:964(17) that defines the term “drug” casts a wide net regarding the types of substances Louisiana law considers to be a drug. ⚕️ Thus, CBD contained in a “drug” product, such as “articles intended to treat disease” or “articles intended to affect the structure of any function of the body of man,” is considered a Schedule V controlled substance.   

Recently, a [FDA report] (https://www.fda.gov/downloads/Drugs/DevelopmentApprovalProcess/SmallBusinessAssistance/UCM462854.pdf ) shed some light on the issue of what the definition of a “drug” is.  Apparently, the previously mentioned language regarding “affecting the structure of any function of the body of man” originated from a federal law, the [Federal Food, Drug, and Cosmetic Act (FD&C Act).  § 321 (2)(g)(1)( C )](https://www.govinfo.gov/content/pkg/USCODE-2010-title21/pdf/USCODE-2010-title21-chap9-subchapII-sec321.pdf) 

Thus, considering the ambiguity surrounding the definition of the term “drug”, it is likely that a court would look to the aforementioned authorities or similar bodies of jurisprudence to determine whether CBD is considered part of a “drug” product.  

## Louisiana’s CBD Safe Harbor Law. 

Perhaps the most effective argument for CBD being legal in Louisiana is derived from language contained in the definition of the term “Cannabis” found in LA R.S. 40:961(6) discussed above.   Recall that the statute, LA R.S. 40:961(6), states that the definition of the term “Cannabis”: 

 “shall not include the mature stalks of such plant, fiber produced from such stalks, oil or cake made from the seeds of such plant, any other compound, manufacture, salt, derivative, mixture, or preparation of such mature stalks (except the resin extracted therefrom), fiber, oil, or cake or the sterilized seed of such plant which is incapable of germination.” 

Accordingly, it follows that CBD is likely considered legal under Louisiana law if it originates from a section of the cannabis plant that’s considered legal, like the “mature stalk” of a cannabis plant. 

------------

[Ambrosia Law Corporation](https://ambrosialaw.com) is a Law Firm based in New Orleans, LA. 🧐 ⚖️   

You can learn more about the Firm by clicking [here](https://ambrosialaw.com/about/). 

> contact the Ambrosia Law Firm @ (504)-400-9926 

> email inquiries to michael@ambrosialaw.com 


_THIS CONTENT IS NOT LEGAL ADVICE_ 


[See More Content](https://ambrosialaw.com/blog/)


 