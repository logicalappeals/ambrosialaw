 --- 
author: "Ambrosia Law" 
date: 2018-12-21 
title: Louisiana Citizen Suits 
best: false 
tags: ["Ambrosia","Law","citizen","Suits","cwa","caa","ldeq","epa","environment"] 
--- 
<!-- Global site tag (gtag.js) - Google Analytics --> 

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script> 

<script> 

  window.dataLayer = window.dataLayer || []; 

  function gtag(){dataLayer.push(arguments);} 

  gtag('js', new Date()); 

  

  gtag('config', 'UA-100888059-7'); 
</script> 

_This content is NOT Legal Advice_

# Louisiana Citizen Suits
### Environmental Law and Compliance  

![image](/img/louisiana-environmental-law.jpg)
(Louisisana Wildlife - _Roseate Spoonbill_)

**Citizen Suits** are generally analyzed under _Environmental Laws_,  

>Citizen Suits in Louisiana.   

Important environmental statutes generally enable "citizen suits."  Citizen suits are brought by citizens against violators (those parties alleged to have committed the pollution) or against agencies that fail to perform mandatory environmental law obligations.  [La RS § 30:2026](http://www.legis.la.gov/Legis/Law.aspx?d=87063), The Louisiana Environmental Quality Act (_see below_), provides for citizens suits in Louisiana.   

Generally, a citizen who wishes to commence an action must give the alleged violator and agencies notice of the citizen's intent to file the lawsuit.  The notice requirement gives the alleged violator a chance to become compliant with the relevant law.  If the alleged violator complies with the law, then the citizen's suit is likely "moot" (there is no longer any actual controversy).

Another requirement for a citizen suit is that the citizen bringing the suit must have "standing" to bring the suit. Basically, standing requires that the party bringing the citizen suit demonstrate a connection between the harm he suffered and the alleged violator’s actions.  
	_Note: A person wishing to bring a citizen suit should allege standing to prevent the suit from being dismissed on the basis of standing._  

In federal citizen suits, citizens are not awarded damages. However, at the state level, in Louisiana, citizens may be awarded damages in citizen suits.  It is also worthwhile to note that if a citizen wins a citizen suit in Louisiana, that citizen may also be entitled to receive their attorney’s fees and costs, injunctive relief, or penalties.

## La RS § 30:2026 - The Louisiana Environmental Quality Act.

------



Citizen suits 

A.(1)  Except as provided in Subsection (B) of this Section, any person having an interest, which is or may be adversely affected, may commence a civil action on his own behalf against any person whom he alleges to be in violation of this Subtitle or of the regulations promulgated hereunder.  The action must be brought either in the district court in the parish in which the violation or alleged violation occurs or in the district court of the domicile of the alleged violator, and shall be afforded preferential hearing by the court. 

(2)  If, at the hearing on the order, it appears to the satisfaction of the court that a violation has occurred, or is occurring, the court may, in order to enforce the provisions of this Subtitle, assess a civil penalty not to exceed ten thousand dollars for each day of the continued noncompliance and the court may, if appropriate, issue a temporary or permanent injunction. 

(3)  The court in issuing any final order in any action brought pursuant to this Section, may award costs of court including reasonable attorneys and expert witness fees to the prevailing party.  The court may also award actual damages to the prevailing plaintiff.  The judgment of the court at the hearing, or subsequently on a petition for fixing the penalty if the violation is a continuing one, shall fix the total amount of penalty due, which shall be collectible under the same procedures as now fixed by law for the collection of money judgments and shall be awarded to and collected by the state of Louisiana and deposited into the state treasury.

B.  No action under this Section shall be commenced under Subsection A:

(1)  Prior to thirty days after the plaintiff has given written notice of the violation to the secretary and to any alleged violator by certified mail, return receipt requested.

(2)  If the secretary or his legal counsel has commenced and is diligently prosecuting a civil or criminal action in a court of this state to require compliance with any standard, limitation, or order; however, in any such action any person having an interest which is or may be adversely affected may intervene as a matter of right.

(3)  If the alleged violator is operating under a variance and is in compliance with the terms of such variance. 

(4)  Against any person while such person, with respect to the same violation is: 

(a)  Under any order issued pursuant to this Subtitle to enforce any provision of this Subtitle.

(b)  A defendant in any civil suit brought under the provisions of R.S. 30:2025. 

(c )  The subject of an action to assess and collect a civil penalty pursuant to R.S. 30:2025(E).

C.  Provided, however, that nothing herein shall be construed to limit or deny any person's right to injunctive or other extraordinary and ordinary relief under the Louisiana Code of Civil Procedure or otherwise under Louisiana law, other than this Section.

D.  The enforcement, procedures, and remedies herein provided for shall be in addition to any such procedures and remedies authorized under the laws of this state.

_This content is NOT Legal Advice_

[Ambrosia Law Corporation](https://ambrosialaw.com) is a Law Firm based in New Orleans, LA. 🧐 ⚖️   

You can learn more about the Firm by clicking [here](https://ambrosialaw.com/about/). 

> contact the Ambrosia Law Firm @ (504)-400-9926 

> email inquiries to michael@ambrosialaw.com 


_THIS CONTENT IS NOT LEGAL ADVICE_ 


[See More Content](https://ambrosialaw.com/blog/)

...

...  

 