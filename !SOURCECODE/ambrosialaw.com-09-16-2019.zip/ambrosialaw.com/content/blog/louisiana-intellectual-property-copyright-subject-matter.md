 --- 
author: "Ambrosia Law" 
date: 2018-12-27 
title: Copyright Subject Matter Part 1 
best: false 
tags: ["Ambrosia","intellectual property","Law","Suits","copyright","louisiana","new orleans","attorney","lawyer"] 
--- 
<!-- Global site tag (gtag.js) - Google Analytics --> 

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script> 

<script> 

  window.dataLayer = window.dataLayer || []; 

  function gtag(){dataLayer.push(arguments);} 

  gtag('js', new Date()); 

  

  gtag('config', 'UA-100888059-7'); 
</script> 

# LOUISIANA INTELLECTUAL PROPERTY  

![image](/img/louisiana-intellectual-property-law.jpg)

## COPYRIGHT – SUBJECT MATTER – PART 1 

_Note: This Content is NOT legal advice_ 

Copyright protections extend to a broad range of subjects.  Works such as: music, movies, poems, books, programs, apps, paintings, advertisements and more are subject to copyright.  Generally, copyright applies to an original work which is fixed in a tangible form of expression.  [17 U.S. Code § 102]( https://www.copyright.gov/title17/92chap1.html) provides general guidelines regarding copyrightable subject matters. 

**17 U.S. Code § 102 - Subject matter of copyright: In general** 

(a) Copyright protection subsists, in accordance with this title, in original works of authorship fixed in any tangible medium of expression, now known or later developed, from which they can be perceived, reproduced, or otherwise communicated, either directly or with the aid of a machine or device. Works of authorship include the following categories: 

(1) literary works; 

(2) musical works, including any accompanying words; 

(3) dramatic works, including any accompanying music; 

(4) pantomimes and choreographic works; 

(5) pictorial, graphic, and sculptural works; 

(6) motion pictures and other audiovisual works; 

(7) sound recordings; and 

(8) architectural works. 

(b) In no case does copyright protection for an original work of authorship extend to any idea, procedure, process, system, method of operation, concept, principle, or discovery, regardless of the form in which it is described, explained, illustrated, or embodied in such work. 

## Copyright Hypothetical Example 

Let us assume that Donald writes a song (or a poem or a book, etc.).  The moment that Donald writes the aforementioned song, he obtains a copyright in the song.  The duration of said copyright is the length of his life plus seventy (70) years. ( _Note_: in instances where an individual produces work product in the course of his employment, the employer holds the copyright in the work and the duration of the copyright is 95 years). 

An individual does not have to register a copyright with the Copyright Office in order to benefit from its protections.  Additionally, the copyright holder does not have to identify the copyrighted work with the copyright symbol, ©, to invoke copyright protections afforded by law.   

Nevertheless, it behooves the copyright holder to register and identify the copyrighted work in order to maximize the extent of his legal protections over the work.  Particularly, it may be easier to prove infringement if the work is registered.  Moreover, registering a work provides a broader range of remedies to the copyright holder in the event the work is infringed.  

## Copyright Holder’s Rights 

[17 U.S. Code § 106]( https://www.law.cornell.edu/uscode/text/17/106), defines the rights of a copyright holder: 

**17 U.S. Code § 106 - Exclusive rights in copyrighted works** 

Subject to sections 107 through 122, the owner of copyright under this title has the exclusive rights to do and to authorize any of the following: 

to reproduce the copyrighted work in copies or phonorecords; (RIGHT TO COPY) 

to prepare derivative works based upon the copyrighted work; (RIGHT TO ADAPT) 

to distribute copies or phonorecords of the copyrighted work to the public by sale or other transfer of ownership, or by rental, lease, or lending; (RIGHT TO DISTRIBUTE) 

in the case of literary, musical, dramatic, and choreographic works, pantomimes, and motion pictures and other audiovisual works, to perform the copyrighted work publicly; (RIGHT TO PUBLIC PERFORMANCE) 

in the case of literary, musical, dramatic, and choreographic works, pantomimes, and pictorial, graphic, or sculptural works, including the individual images of a motion picture or other audiovisual work, to display the copyrighted work publicly; (RIGHT TO DISPLAY) and 

in the case of sound recordings, to perform the copyrighted work publicly by means of a digital audio transmission. (RIGHT TO STREAM) 

Consider the aforementioned example of Donald, the songwriter.  The following activities may infringe upon Donald’s copyright in his song: 

* Copying the elements of his song into another song  _See:_ [The “Blurred Lines” Lawsuit]( https://www.rollingstone.com/music/music-news/robin-thicke-pharrell-lose-multi-million-dollar-blurred-lines-lawsuit-35975/) 

* Copying and selling a recording of the song 

* Reproducing the textual language of the song 

* Preforming the song in public 

Nevertheless, various elements of this work may not be protected by copyright such as functional elements of the work, elements of the work that are not created by the author, and “ideas.”  Thus, things such as ideas, facts, mathematical operators, and other similar elements are not copyrightable and will limit the copyright protections afforded to a given work.   

Moreover, “Fair Use” provides that parodies of a work may be produced and copied without violating the copyright protections afforded to the original work.   Other examples of “Fair Use” include distributing “Xeroxed” copies of copyrighted materials to students in a class or using portions of a copyrighted material in a review.  

Donald’s copyright rights afford him the ability to control the sale, production, and distribution of his work.  Notwithstanding the aforementioned “ideas” and “Fair Use” defenses, the copyright holder determines how a work may be translated to other languages and adapted.  Thus, a copyright holder may control the commercial distribution of the work as well as the public dissemination of the work (except for things like reviews and other public commentary).  The copyright holder may also license his work subject to various terms and conditions.  For example, the copyright holder may grant a business a license to use a song for one year. 

Also, a copyright holder may prohibit the publishing of a particular work.  In this way, certain copyright holders may purchase the “rights” of a work only to “shelve” it and prevent the publishing and distribution of said work.   

## General Remedies Available to Copyright Holders 

Copyright law is a matter of federal question because federal law governs copyrights; thus, the copyright holder may sue an alleged infringer for a copyright violation in federal court.   

The copyright holder may receive from the alleged infringer: injunctive relief (generally, a court order for the infringer to refrain from doing something), damages, or control over the infringing copies.   

If a copyright holder registers his copyright prior to the infringement, the copyright holder may option to receive “statutory damages” (damages provided for by law) as opposed to “actual damages.”  Moreover, in these instances, the copyright may also recover his attorney’s fees.  

[Ambrosia Law Corporation](https://ambrosialaw.com) is a Law Firm based in New Orleans, LA. 🧐 ⚖️   

You can learn more about the Firm by clicking [here](https://ambrosialaw.com/about/). 

> contact the Ambrosia Law Firm @ (504)-400-9926 

> email inquiries to michael@ambrosialaw.com 


_THIS CONTENT IS NOT LEGAL ADVICE_ 


[See More Content](https://ambrosialaw.com/blog/)



 