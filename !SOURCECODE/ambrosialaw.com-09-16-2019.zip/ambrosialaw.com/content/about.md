+++
date = "2018-11-23"
title = "About"
+++

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-100888059-7');
</script>

<center>**Ambrosia Law Corporation** - _**A Professional Law Corporation**_</center>
<center>A **New Orleans**, **Louisiana** Law Firm.</center> 

![image](/img/ambrosia-law-new-orleans.jpg)


	Contact the Ambrosia Law Firm
	-----------------------------
	Lakeview office: 932 Hidalgo Street, New Orleans, LA 70124 
	Mid-City office: 422 S. Broad Ave., New Orleans, LA 70119   
    phone: (504) 400 - 9926
    email: michael@ambrosialaw.com 

Ambrosia is a New Orleans ⚜️, Louisiana based law firm 🏛️ 🧐 ⚖️

>Founding Partner: **Michael Vincent Ambrosia, Esq.** _(Licensed Louisiana Attorney and Notary Public)_

>Michael earned a Juris Doctor in Civil Law from the Loyola University School of Law in New Orleans.  He is admitted to practice before all Louisiana State Courts.

>Michael is a New Orleans native - he resides in Lakeview with his wife, Hillary, and their daughter, Aria, together with their wolf-dog, Bodhi 🐺, and cat, Meow-Meow 🐈.







 