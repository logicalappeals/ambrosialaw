 --- 
author: "Ambrosia Law" 
date: 2019-07-30 
title: Louisiana Makes CBD Legal
best: false 
tags: ["Louisiana","marijuana","cannabis","CBD","attorney","lawyer","new orleans"] 
--- 
<!-- Global site tag (gtag.js) - Google Analytics --> 

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script> 

<script> 

  window.dataLayer = window.dataLayer || []; 

  function gtag(){dataLayer.push(arguments);} 

  gtag('js', new Date()); 

  

  gtag('config', 'UA-100888059-7'); 
</script> 

![Louisiana Makes CBD Legal](/img/louisiana-makes-cbd-legal.jpg "Louisiana Makes CBD Legal")

# Louisiana Makes CBD Legal 

Recently, on June 6, 2019, through [Act 164 of the 2019 regular session of the Louisiana legislature](http://www.legis.la.gov/Legis/BillInfo.aspx?i=236337), Louisiana law makers legalized Cannabidiol ("CBD") for certain limited uses. 

## Louisiana Law Makers Legalize CBD

Specifically, HB491 proposed by [Republican Louisiana State Representative, Clay Schexnayder](http://house.louisiana.gov/H_Reps/members.aspx?ID=81), paved the way for CBD legalization in Louisiana. HB491 is entitled "AGRICULTURAL COMMODITIES" and Provides for the regulation of industrial hemp.  HB491 was Signed into law by Louisiana Governor, Jon Bel Edwards, as part of Act 164 on June 6, 2019.  

In particular, Act 164 legalized the use of industrial hemp in Louisiana.  Industrial Hemp was previously declassified from being a Schedule 1 controlled dangerous substance by the US Congress as part of the [2018 "Farm Bill"](https://www.farmers.gov/farmbill). 

Industrial hemp is derived from the Cannabis plant.

## Is Hemp Legal in Louisiana? 

Well, that depends . . .
The aforementioned legislation signifies that Louisiana law makers recognize that industrial hemp is an agricultural commodity; thus, the legislature legalized the cultivation and harvesting of hemp under certain conditions. 

Nevertheless, to grow hemp in Louisiana, a farmer must be a USDA-licensed hemp grower or have a license issued by the [Louisiana Department of Agriculture and Forestry](http://www.ldaf.state.la.us/).  Moreover, Louisiana’s Food, Drug and Cosmetic laws requires that Louisiana hemp farmers must register with the [Louisiana Department of Health and Human Services](http://ldh.la.gov/) to remain compliant with Louisiana law.


## What Forms of CBD are legal in New Orleans and Louisiana?

It is worthwhile to consider that Louisiana law makers did not entirely legalize CBD.  
The sale, distribution, and consumption of CBD in Louisiana is subject to additional restrictions.  

In New Orleans and the rest of Louisiana, CBD products may NOT be used as an inhalant.  This effectively outlaws "vaping" or smoking CBD products.  Therefore, all of those fancy vape "cartridges", "dabs" or "CBD flower" products intended for vaping or smoking are still illegal in Louisiana.

Moreover, Louisiana law prohibits selling and consuming CBD in alcoholic beverages and food products (unless and until such products are approved by the US FDA).  CBD products marketed as "dietary supplements" are also against the law in Louisiana. 

## What are the Requirements to Sell CBD in Louisiana?

CBD products sold in Louisiana are subject to strict labeling requirements - this includes displaying a disclaimer/warning stating that the CBD product has not been evaluated by the FDA.  Also, the products must have a bar code that provides a link between the particular product and its corresponding certificate of analysis. 

In Louisiana, CBD may NOT have a concentration of more than 0.3% of tetrahydrocannabinol ("THC"). THC is the chemical in cannabis/marijuana/hemp that is responsible for getting the user "high." Additionally, CBD products must be analyzed by a state approved laboratory to determine the THC concentration of the product and the corresponding Certificate of Analysis ("COA") must be filed with the Louisiana Department of Health and Human Services

# How do I get a license to sell CBD products in Louisiana?

The licensing of wholesale and retail distributers of CBD products in Louisiana is performed by [The Louisiana Office of Alcohol and Tobacco Control ("ATC").](http://www.atc.rev.state.la.us/) 

If you want to sell CBD products in Louisiana, you must register a list of the CBD products you intend to sell with the ATC. 

[Applications to register as a CBD retailer in Louisiana](http://www.atc.rev.state.la.us/cbd.php) are available through the ATC.  The licensing fee and application costs $175.00.

### Are CBD Products Taxed in Louisiana?

CBD products sold in Louisiana are subject to a tax rate of three (3) % percent as well as state and local sales tax.  


_Note: This Content is NOT legal advice and should NOT be taken as such._  - _If you have a legal question, please consult with an attorney._  

------------

[Ambrosia Law Corporation](https://ambrosialaw.com) is a Law Firm based in New Orleans, LA. 🧐 ⚖️   

You can learn more about the Firm by clicking [here](https://ambrosialaw.com/about/). 

> contact the Ambrosia Law Firm @ (504)-400-9926 

> email inquiries to michael@ambrosialaw.com 

[See More Content](https://ambrosialaw.com/blog/)


 