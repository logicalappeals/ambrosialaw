 --- 
author: "Ambrosia Law" 
date: 2018-12-26 
title: Environmental Citizen Suits Notice 
best: false 
tags: ["Ambrosia","notice","Law","citizen","Suits","cwa","caa","ldeq","epa","environment"] 
--- 
<!-- Global site tag (gtag.js) - Google Analytics --> 

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script> 

<script> 

  window.dataLayer = window.dataLayer || []; 

  function gtag(){dataLayer.push(arguments);} 

  gtag('js', new Date()); 

  

  gtag('config', 'UA-100888059-7'); 
</script> 

# LOUISIANA CITIZEN SUITS - NOTICE  

## Environmental Law -  Pre Suit Notice Requirements  

![image](/img/citizen-suit-notice.jpg)

_Note: This Content is NOT legal advice_ 

Plaintiffs in **citizens suits** are required by [La RS § 30:2026(B)(1)](http://legis.la.gov/Legis/Law.aspx?d=87063) to give the alleged violator and the Secretary of the [LDEQ](https://deq.louisiana.gov/) notice of the alleged violation in writing via certified mail with return receipt requested thirty (30) days before the suit is filed.  This time period is sometimes referred to as a “cooling” period. 

This requirement is significant for a suit may be dismissed on the basis that it is “premature” if the plaintiffs do not give the aforementioned notice.  

A relevant Federal Case regarding the “notice aspect” of citizen suits is: [_Public Interest Research Group of New Jersey, Inc. vs. Hercules, Inc._, 50 F.3d 1239, 1248 (3d Cir. 1995)](https://casetext.com/case/public-interest-research-group-v-hercules).  

In instances where an alleged violator becomes compliant with the relevant laws within the “cooling” off period, the alleged violator may seek to bolster his defense of the suit through negotiating a “bona fide” settlement with the applicable enforcement agency.   The case, [_Lockett vs. E.P.A._, 319 F.3d 678 (5th Cir. 2003)](https://www.leagle.com/decision/2003997319f3d6781928), contains information relevant to the aforementioned strategy.   

Additionally, a potential suit may be rendered “moot” and unable to proceed in situations where future violations become impossible.  An example of this is [_Friends of the Earth, Inc. et al. v. Laidlaw Environmental Services, Inc._, 528 U.S. 167 (2000)](https://supreme.justia.com/cases/federal/us/528/167/). 

### Citizen Suit Notice Letter Requirements 

Certain Federal cases such as [_Natural Resources Defense Counsel v. Southwest Marine, Inc._, 236 F.3d 985 (9th Cir. 2000)](https://openjurist.org/236/f3d/985)., reference the requirements for giving notice to an alleged violator under federal citizen suit statutes like the Clean Water Act.  The language of the relevant statutes coupled with corresponding jurisprudence reveals that a notice letter to an alleged violator should include at least: 

*The details of the alleged violation 

* A reasonable description of the alleged violator’s failure to maintain a plan to prevent pollution 

* The Dates of the alleged violation  

* The reservation of the right to amend the notice for subsequent violations 

* Contact information for the plaintiff or counsel. 

_THIS CONTENT IS NOT LEGAL ADVICE_ 

[Ambrosia Law Blog](https://ambrosialaw.com) 🧐 ⚖️   

You can learn more about the Blog by clicking [here](https://ambrosialaw.com/about/). 


_THIS CONTENT IS NOT LEGAL ADVICE_ 


[See More Content](https://ambrosialaw.com/blog/)



 