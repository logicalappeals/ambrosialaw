 --- 
author: "Ambrosia Law" 
date: 2019-09-16 
title: How to Pass the Louisiana Bar Exam Part 1
best: false 
tags: ["Louisiana","bar","exam","attorney","lawyer","new orleans"] 
--- 
<!-- Global site tag (gtag.js) - Google Analytics --> 

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script> 

<script> 

  window.dataLayer = window.dataLayer || []; 

  function gtag(){dataLayer.push(arguments);} 

  gtag('js', new Date()); 

  

  gtag('config', 'UA-100888059-7'); 
</script> 



# How to Pass the Louisiana Bar Exam 

 
 

## Part 1 - Introduction to the Louisiana Bar Exam


The bar exam is no fun.

The Louisiana bar exam is a three day long exam.  Three days of pure torture.  

The bar exam is a rite of passage for every wanna-be lawyer. There's no away around it. (Wisconsin is an exception - it does not have a mandatory bar exam. Wisconsin still uses ["diploma privilege."](https://en.wikipedia.org/wiki/Diploma_privilege) Students who graduate from a Wisconsin state law school can practice law there. **Ridiculous**.) 

The bar exam is a necessary evil that separates the proverbial wheat from the chaff. It serves to weed out imposters and prevent market saturation.  
![How to Pass the Louisiana Bar Exam](/img/how-to-pass-louisiana-bar-exam.jpg "How to Pass the Louisiana Bar Exam")
<center>(some of my bar exam study materials)</center> 

### The Bar Exam and the Regulated Market 

A few months ago, one of my mentors told me a bar exam horror story about one of his paralegals, let's call him John. The mentor told me how John went to law school, graduated, sat for the Louisiana bar exam and failed. John took the bar exam a second time and failed it again. He took it a third time and failed once more. After his third failed attempt, John became fed up with expending time, money, and energy on the bar exam. He decided to become a construction manager instead. 

In an age where third-tier, for-profit law schools pump out J.D.s by the thousands, the bar exam is the great equalizer. 

### "Smart" People Fail the Bar Exam 

 
When it comes to the bar exam, you can't fake it. The bar exam crushes peoples' hopes and dreams.  

Know this. Not everyone is as **"smart"** as they appear on the outside. Often, the media glorifies certain individuals for being brilliant or stunning and brave. _Cue the Smoke & Mirrors_.  

Those who attend top law schools or hold positions of power can become victims of hubris. For example, [Hillary Clinton, Michelle Obama, J.F.K Junior, and F.D.R. failed the bar exam](https://www.lawcrossing.com/article/900047908/These-Famous-People-Didnt-Let-Failing-the-Bar-Get-Them-Down/). Never judge a book by its cover. **Nothing is what it seems**.  

### Get it how you live.  

I was never the "best" law student. During my 1L year, the majority of my peers spent most of their time studying. I didn't have that luxury. Between classes, I worked two part-time jobs at all hours of the night to support my wife and newborn daughter. Fun times. I got by on pure grit and determination. **Hard work**.  

I excelled in classes I was passionate about and passed the other classes by the skin of my teeth.

I always believed I was intelligent. The only time in my life when I questioned my intelligence was when I was preparing for the bar exam. Still, I dug my heels in and hit the books day in and day out for months straight - **I passed the first time**.  

### To beat the bar exam, you have to become the bar exam. 

When I was studying for the [Louisiana bar exam](https://lascba.org/BarExam/Default.aspx), I took every previous exam from the past 12 years. Only then did I begin to realize the exams' patterns. Questions, themes, and rules of law would repeat themselves from test to test. When I recognized a repeating theme, I familiarized myself with it and commit to memory.  

The more I studied for the bar, the more I noticed how the tests would change with the examiners. Each examiner has a different style. Some examiners are more difficult than others. Certain tests on the Louisiana bar exam are notoriously difficult. Today, Code III is considered the hardest test on the Louisiana bar exam. It wasn't always like that. Before the bar examiners ramped up the difficulty on Code III, the Code II section was exceptionally hard.  

One of the best pieces of advice I received while studying for the Louisiana bar came from a close friend of mine. My friend was a year ahead of me in law school. He took and passed the Louisiana bar exam the year before me.  

When I was about two months into studying for the bar, my friend visited me. I took a break from studying to chat with him, in part, to regain part of my sanity. (My sanity was slipping away, day by day. What was once my brain became a hodgepodge of rules, exceptions, and mnemonics.) My friend told me "don't waste your time with those outlines and extra review sessions the school provides, spend your time taking those old tests."  

Thereafter, I changed my study strategy and started reviewing the earlier exams non-stop. This piece of advice was invaluable, without it I may not have passed.  

In sum, history repeats itself. Learn to recognize patterns, they are your friends.  

### Oral Tradition and the Louisiana Bar Exam 

You can't "brute force" your way through the bar exam, there is too much material to memorize it all. For this reason, mnemonic devices are crucial. [Mnemonics aid the memorization of copious amounts of material.](https://en.m.wikipedia.org/wiki/Mnemonic) Humans have used mnemonics for thousands of years. Mnemonics will help you make sense of all the material you must commit to memory for the bar exam.  

Memorizing paragraphs of legal catechisms word-for-word may seem like overkill, but that is what you must do to pass the Louisiana bar exam. 

To maximize your point spread you must: 

(1) identify a legal issue; 

(2) recall a rule of law from memory; and 

(3) apply the rule of law to the facts at hand. 

If you miss one step in this process, you're not in a position to earn all of the [possible points](https://lascba.org/BarExam/Default.aspx?tab=scoring).  

Once, a bar examiner told me that the bar exam is like running through the jungle and picking up as many low hanging fruits as you can. You won't get everything, but you want to get as much as you can.  

### To Each Their Own 

When it comes to learning, everyone has a unique style and personal preference. Some people like outlines, some use flashcards and re-reading notes.  

For the bar exam, I preferred [post-it notes](https://en.wikipedia.org/wiki/Post-it_Note). Post-it notes were great for me. I could write mnemonics and rules on them, group them, and re-arrange them to try to see the "big picture." I would stick the post-its on blank pieces of paper and organize them by subject matter to form what I called "hot sheets."  

![Louisiana Bar Exam Study](/img/louisiana-bar-exam-study.jpg "Louisiana Bar Exam Study")
<center>(some of my "hot sheets")</center> 

Hot sheets were my form of super-condensed outlines that held the most critical information for each topic. If I picked up a pattern or thought that something would show up on a test, it went on the hot sheets. I memorized the hot sheets. They served me well.  

In future posts, I'll share some of my favorite mnemonics, strategies, and hot sheets.  


_Note: This Content is NOT legal advice and should NOT be taken as such._  - _If you have a legal question, please consult with an attorney._  
------------

[Ambrosia Law Blog](https://ambrosialaw.com) is a Law Blog 🧐 ⚖️   

You can learn more about the Blog by clicking [here](https://ambrosialaw.com/about/). 

[See More Content](https://ambrosialaw.com/blog/)


 