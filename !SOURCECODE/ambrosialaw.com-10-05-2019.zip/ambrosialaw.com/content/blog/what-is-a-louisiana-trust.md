 --- 
author: "Ambrosia Law" 
date: 2019-02-14 
title: What is a Louisiana Trust 
best: false 
tags: ["louisiana","trust","estate","will","trusts","attorney","lawyer","new orleans"] 
--- 
<!-- Global site tag (gtag.js) - Google Analytics --> 

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script> 

<script> 

  window.dataLayer = window.dataLayer || []; 

  function gtag(){dataLayer.push(arguments);} 

  gtag('js', new Date()); 

  

  gtag('config', 'UA-100888059-7'); 
</script> 

# What is a Louisiana Trust? 

This article is part of a series of articles that explore the basics of Louisiana Trust law.  The content covers different types of Louisiana trusts and the basis for choosing one type of trust over another.   

![Louisiana Trust Attorney](/img/louisiana-trust-attorney.jpg "Louisiana Trust Lawyer")

_Note: this content is NOT Legal advice_ 

_If you have a legal question please consult with a qualified Louisiana Attorney._ 

## Louisiana Trust Code 

The Louisiana Trust Code is found in the Louisiana Revised Statutes.[RS 9:1721](https://www.legis.la.gov/Legis/Law.aspx?p=y&d=106739) is the first statute in the Louisiana Trust Code.  RS 9:1721 states: 

“CODE TITLE II--OF DONATIONS INTER VIVOS(BETWEEN LIVING PERSONS) AND MORTIS CAUSA (IN PROSPECT OF DEATH) CHAPTER 1.  LOUISIANA TRUST CODE PART I.  PRELIMINARY PROVISIONS  

§1721.Title  

This Chapter shall be known and may be cited as the Louisiana Trust Code.” 

## What is the Definition of a Trust? 

[RS 9:1731](https://www.legis.la.gov/Legis/Law.aspx?d=106745) defines the term “Trust.”   

### Trust defined  

A trust, as the term is used in this Code (the LA Trust Code), is the relationship resulting from the transfer of title to property from one person (known as the *settlor*) to another person (known as the *trustee*) to be administered by him as a fiduciary for the benefit of another (known as the *beneficiary*). RS 9:1731. 

In simple terms, a trust is a mechanism whereby one or multiple people may manage property on behalf of another.   

## What are the Different Kinds of Louisiana Trusts?  

### Louisiana Inter Vivos Trusts and Testamentary Trusts 

A trust is created by a person known as the settlor.  If the trust is established by the settlor while he is alive, the trust is referred to as an “inter vivos trust.”  

If the trust is established by the settlor following his death, such as in his will (aka testament), then the trust is a “testamentary trust.” 

### Louisiana Revocable and Irrevocable Trusts 

A *revocable trust* may be modified or revoked by the settlor.  If a trust is revoked, the property held in trust returns to the settlor.  The Louisiana Trust Code states that the settlor may revoke a trust; nevertheless, “The delegation (to revoke the trust) may be accomplished only by an express statement in the trust instrument or in a power of attorney executed by authentic act referring to the trust. [RS 9:2045](https://www.legis.la.gov/Legis/Law.aspx?d=106894) 

An *irrevocable trust* may not be modified or revoked by the settlor. [RS 9:2041](https://www.legis.la.gov/Legis/Law.aspx?p=y&d=106890) As a general rule, a trust is irrevocable unless the settlor reserves the right to modify or revoke it.  Once the settlor dies, a revocable trust becomes irrevocable through the operation of law.  

## Who is the Settlor in a Louisiana Trust? 

§1761.  Settlor defined  

A settlor is a person who creates a trust.  A person who subsequently transfers property to the trustee of an existing trust is not a settlor.  [RS 9:1761](https://www.legis.la.gov/Legis/Law.aspx?d=106760) 

## Who is the Trustee in a Louisiana Trust? 

§1781.  Trustee defined  

A trustee is a person to whom title to the trust property is transferred to be administered by him as a fiduciary. [RS 9:1781](https://www.legis.la.gov/Legis/Law.aspx?d=106767) 

## Who is the Beneficiary in a Louisiana Trust? 

§1801.  Beneficiary defined  

A beneficiary is a person for whose benefit the trust is created and may be a natural person, corporation, partnership, or other legal entity having the capacity to receive property. [RS 9:1801](https://www.legis.la.gov/Legis/Law.aspx?d=106780) 

------------

[Ambrosia Law Blog](https://ambrosialaw.com) is a Law Blog based in New Orleans, LA. 🧐 ⚖️   

You can learn more about the Blog by clicking [here](https://ambrosialaw.com/about/). 

_THIS CONTENT IS NOT LEGAL ADVICE_ 


[See More Content](https://ambrosialaw.com/blog/)





 