 --- 
author: "Ambrosia Law" 
date: 2019-03-05 
title: Louisiana Cyberbullying Law 
best: false 
tags: ["Louisiana","Cyberbullying","criminal","attorney","lawyer","new orleans"] 
--- 
<!-- Global site tag (gtag.js) - Google Analytics --> 

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script> 

<script> 

  window.dataLayer = window.dataLayer || []; 

  function gtag(){dataLayer.push(arguments);} 

  gtag('js', new Date()); 

  

  gtag('config', 'UA-100888059-7'); 
</script> 

![Louisiana Cyberbullying Law](/img/louisiana-cyberbullying-law.jpg "Louisiana Cyberbullying Law")

# What are Louisiana Cyberbullying Laws? 

Louisiana cyberbullying laws criminalize activities involving the transmission of any electronic textual, visual, written, or oral communication with the malicious and willful intent to coerce, abuse, torment, or intimidate a person under the age of eighteen. 

## What is the definition of Cyberbullying? 

Louisiana law defines Cyberbullying as “the transmission of any electronic textual, visual, written, or oral communication with the malicious and willful intent to coerce, abuse, torment, or intimidate a person under the age of eighteen.” 

## Is Cyberbullying Illegal in Louisiana? 

Yes, cyberbullying is a crime in Louisiana.  In 2010, the Louisiana Legislature made cyberbullying illegal in the State of Louisiana. 

Title 14 of the Louisiana Revised Statutes is commonly referred to as the “Louisiana Criminal Code.”  A plethora of different laws governing criminal conduct in Louisiana are contained therein.  The Louisiana Criminal Code defines a variety of different types of crimes such as: 

[§357.  Candies, selling without payment of license tax; penalty](https://www.legis.la.gov/legis/Law.aspx?d=78464) 

[§313. Wearing of masks, hoods, or other facial disguises in public places prohibited; penalty; exceptions; permit to conduct Mardi Gras festivities;](https://www.legis.la.gov/legis/Law.aspx?d=78402) 

[§91.21.  Sale of poisonous reptiles to minors; penalty](https://www.legis.la.gov/legis/Law.aspx?d=78710) 

Title 14 also defines the more egregious crime of “Cyberbullying.” 

### The Louisiana Cyberbullying Statute   

[LA RS §40.7. Cyberbullying](https://www.legis.la.gov/legis/Law.aspx?d=725180) 

§40.7.  Cyberbullying 

A.  Cyberbullying is the transmission of any electronic textual, visual, written, or oral communication with the malicious and willful intent to coerce, abuse, torment, or intimidate a person under the age of eighteen. 

B.  For purposes of this Section: 

(1)  "Cable operator" means any person or group of persons who provides cable service over a cable system and directly, or through one or more affiliates, owns a significant interest in such cable system, or who otherwise controls or is responsible for, through any arrangement, the management and operation of such a cable system. 

(2)  "Electronic textual, visual, written, or oral communication" means any communication of any kind made through the use of a computer online service, Internet service, or any other means of electronic communication, including but not limited to a local bulletin board service, Internet chat room, electronic mail, or online messaging service. 

(3)  "Interactive computer service" means any information service, system, or access software provider that provides or enables computer access by multiple users to a computer server, including a service or system that provides access to the Internet and such systems operated or services offered by libraries or educational institutions. 

(4)  "Telecommunications service" means the offering of telecommunications for a fee directly to the public, regardless of the facilities used. 

C.  An offense committed pursuant to the provisions of this Section may be deemed to have been committed where the communication was originally sent, originally received, or originally viewed by any person. 

D.(1)  Except as provided in Paragraph (2) of this Subsection, whoever commits the crime of cyberbullying shall be fined not more than five hundred dollars, imprisoned for not more than six months, or both. 

(2)  When the offender is under the age of seventeen, the disposition of the matter shall be governed exclusively by the provisions of Title VII of the Children's Code. 

E.  The provisions of this Section shall not apply to a provider of an interactive computer service, provider of a telecommunications service, or a cable operator as defined by the provisions of this Section. 

F.  The provisions of this Section shall not be construed to prohibit or restrict religious free speech pursuant to Article I, Section 8 of the Constitution of Louisiana. 

## Louisiana Cyberbullying Remedies 

A variety of civil and criminal legal remedies are available to victims of cyberbullying: 

### Criminal Remedies For Louisiana Cyberbullying Victims 

Those who commit the crime of cyberbullying may be arrested, prosecuted, fined, and imprisoned.   

### Civil Remedies For Louisiana Cyberbullying Victims 

Victims of cyberbullying may sue the alleged cyberbully/offender for damages related to the offense.   


_Note: This Content is NOT legal advice and should NOT be taken as such._  - _If you have a legal question, please consult with an attorney._  


[Ambrosia Law Blog](https://ambrosialaw.com) is a Law Blog based in New Orleans, LA. 🧐 ⚖️   

You can learn more about the Blog by clicking [here](https://ambrosialaw.com/about/). 
 

[See More Content](https://ambrosialaw.com/blog/)

 