+++
date = "2018-11-23"
title = "About"
+++

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-100888059-7');
</script>

<center>**Ambrosia**</center>

>   Ambrosia is a blog about the law.
🏛️ 🧐 ⚖️



![image](/img/ambrosia-law-new-orleans.jpg)


<center>This website is not legal advice.</center>







 