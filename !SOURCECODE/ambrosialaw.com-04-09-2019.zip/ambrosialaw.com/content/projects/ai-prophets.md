+++
title = "AI Prophets"
description = "Learn About the Minds Powering Artificial Intelligence"
date = "2018-11-01"
tags = ["projects","AI","prophets","artificial intelligence"]
+++

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-100888059-7');
</script>

<center>[AI Prophets](https://aiprophets.com)</center>

![image](/img/ai-attorney.jpg) 
 
> An interactive Visual Based Grid that explores the top minds in the field of AI, Artificial Intelligence.  

