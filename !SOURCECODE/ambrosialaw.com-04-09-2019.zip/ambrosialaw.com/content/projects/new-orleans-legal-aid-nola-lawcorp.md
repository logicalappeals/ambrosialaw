+++
title = "New Orleans Legal Aid"
description = "New Orleans Legal Aid (NOLA) Lawcorp serves to increase access to justice throughout the New Orleans, Louisiana metropolitan area."
date = "2018-10-20"
tags = ["projects","NOLA","New Orleans","law", "legal","aid"]
+++

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-7"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-100888059-7');
</script>

![image](/img/new-orleans-legal-aid.jpg) 
 
## [New Orleans Legal Aid - NOLA LAW CORP](https://nolalawcorp.com)

> New Orleans Legal Aid (NOLA) Law Corp's mission is to increase access to justice throughout New Orleans and all of Louisiana. 
